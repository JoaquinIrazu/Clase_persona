class Gato {
  constructor(name, color) {
    this.name = name;
    this.color = color;
    this.energy = 100;
  }

  energyMsg = "No tienes suficiente energia";


  eat() {
    this.energy = 100;
  }

  hunt() {
    if (this.energy < 50) {
      return energyMsg;
    }
    this.energy = 50;
  }

  play() {
    if (this.energy < 30) {
      return energyMsg;
    }
    this.energy = 30;
  }

  showData() {
    return `Tu gato se llama ${this.name} y es de color ${this.color}`;
  }
}
